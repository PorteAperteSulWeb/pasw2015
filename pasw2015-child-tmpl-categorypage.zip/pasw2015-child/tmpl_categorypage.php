<?php get_header(); ?>
<?php get_sidebar(); ?>
<?php global $children; ?>
<?php if (have_posts()){
        while (have_posts()) : the_post();
?>            <div class="post" id="post-<?php the_ID(); ?>">

                <h2 class="posttitle"><?php the_title(); ?></h2>

                <?php $children = wp_list_pages('depth=1&title_li=&child_of='.$post->ID."&echo=0");
                if($children && (get_option( 'pasw_submenu') != '3' && get_option( 'pasw_submenu') != '4')) {
                    //Genera CSS
                    if (get_option( 'pasw_submenu') == '0') { //Verticale SX

                    } else if (get_option( 'pasw_submenu') == '1') { //Verticale DX
                        $subcss=' style="float:right;"';
                    } else if (get_option( 'pasw_submenu') == '2') { // Orizzontale
                        $subcss=' style="width:100%;"';
                        echo '
                        <style type="text/css">
                            .sotto-pagine li { float:left; }
                        </style>';
                    } ?>
                <div class="sotto-pagine" <?php echo $subcss; ?>>
                    <ul>
                        <?php wp_list_pages('depth=1&title_li=&child_of='.$post->ID); ?>
                    </ul>
                </div>
                <?php if (get_option( 'pasw_submenu') == '2') { echo '<div class="clear"></div>';
                    }
                }?>
                <div class="postentry">
                    <?php the_content(__('Leggi il resto &raquo;')); ?>
                </div>
            </div>
<?php   endwhile; } ?>

</div>
<?php
get_sidebar('right');
get_footer();
?>
